# 06 · Motion system

The motion goal is to feel like iOS (springy, fluid, staged) and to read like motion graphics: every reveal is choreographed, nothing simply appears.

## Easing tokens

| Token | Curve | Use |
| --- | --- | --- |
| `--ios` | `cubic-bezier(.32,.72,0,1)` | Apple sheet curve: morphs, card widen, globe pop, folds |
| `--out` | `cubic-bezier(.16,1,.3,1)` | Things **entering** |
| `--in` | `cubic-bezier(.7,0,.84,0)` | Things **leaving** |
| in-out | `cubic-bezier(.65,0,.35,1)` | Moving between two places on screen |
| `--pop` | `cubic-bezier(.34,1.56,.64,1)` | Small overshoot: icon lift |
| `--calm` | `cubic-bezier(.22,.8,.24,1)` | **Large** surfaces: no overshoot, no colour flash |
| `--spring` | CSS `linear()`, about 1.7% overshoot | Panels, pills, pins, callouts (bouncy open) |
| `--spring-pop` | CSS `linear()`, about 16% overshoot | Small lifts and presses |

The full `linear()` spring strings are in `library/tokens.css`. Linear easing is only for spinners, progress and tickers.

## Durations

| Moment | Open | Close |
| --- | --- | --- |
| Hover / press feedback | 100–150ms (press 90ms) | — |
| Icon label reveal | 200–240ms, 60ms delay | 120ms |
| Icon lift | 220ms `--pop` | — |
| Conversation morph (globe → card) | **460ms `--ios`** | **260ms ease-in** |
| Conversation children | stagger 40ms, starting 140ms | 80ms |
| Globe pop | 420–460ms | 160–200ms |
| Rail card / chapter expand | 380ms `--calm` (+70ms intent) | 300ms (+240ms delay) |
| Optional detail panel | 240ms | 160ms |
| Callout sequence | 520–560ms total | 260ms |
| Camera reframe for a panel | 300–520ms | same |
| Camera focus / orbit | 450–700ms, along arcs | — |
| Document: lift / cover / slide / close | 420 / 400–460 / 300 / 350ms | — |
| Page swap | 180ms | — |
| Globe shape morph | 600ms ease-in-out | — |
| Word stream | 34ms per word, after the card has opened | — |
| Scene cross-dissolve (into the indigo model stage) | 700ms | — |
| Opener → title fade | 420ms | — |

**Rule of thumb:** small feedback 100–150ms; most UI 150–300ms; big panels up to about 460ms. Anything over 500ms only for one-time moments (onboarding, scene changes, films).

## The ten rules we actually live by

1. **Close faster than you open.** Exit takes ½ to ⅓ of the entry, with an ease-in. (Cover close was set 14× faster than open; composer exit 160ms.)
2. **Stage one thing at a time.** Container first, contents second, children 30–60ms apart, the whole cascade under about 300ms.
3. **Grow from the trigger (origin awareness).** The conversation grows from the globe; cards from their pin; the tools menu from the tools button; the input pill from the bubble.
4. **Springs for small things, calm curves for big things.** Overshoot on a 44px icon feels alive; on a 340px panel it feels sloppy.
5. **Everything is interruptible.** Use CSS transitions or tweens that retarget from the current value. Never keyframes for anything reversible. Never block input while moving.
6. **Nothing idles.** No auto-spin, no constant pulse, no breathing unless the agent is speaking. The scene holds still while the learner reads or types.
7. **Move in arcs.** Camera moves curve; diagonal travel uses different easing per axis.
8. **Respond within 100ms.** Show something immediately; real work over 400ms shows progress (globe "thinking", year ticks).
9. **The more frequent, the less motion.** Hover is near-instant. A first-time film or onboarding can take its time.
10. **Reduced motion means the same end state, instantly** (or a brief fade). Implement it both through `@media (prefers-reduced-motion)` and an in-app **Pause motion** toggle (`body.reduced`).

## Signature choreographies

### Callout ("motion-graphics layer")
`0ms` highlight object → `0–180ms` corner brackets lock on → `120–360ms` dotted leader draws to the margin → `300–520ms` card springs out of the line's end. Leave: everything reverses in about 260ms.

### Dynamic Island conversation
Globe pops (scale 0.6 → 1) → card clips open from the globe's circle (460ms) → speaker, line, input and actions rise 10px and fade in, staggered → the globe "thinks" about 0.5s → words stream in 34ms apart. Close: content off in 80ms → clip back to the circle in 260ms.

### Rail announce
A new chapter opens the rail for about 5s (`body.rail-announce`) → cards fold to 64px icon tabs → the model reframes to the full preview. Hover brings a card back.

### Document
Lift and square to camera → cover opens while holding still → one sheet slides straight right → tag → return along the same path. No curl, fanning or idle tease.

### Sorting a sheet
The sheet lifts out of the reader → folds once (the bottom half rotates in 3D) → flies along an arc to its folder → a thin outline draws round it → the folder acknowledges.

### Simulation run (Orizon)
The map dims and the arcs redraw as a progress ring → year ticks (Year 2, 4, 6, 8, 10) light in sequence, 300ms then every 600ms → the camera arcs round the map → the result is spotlit. Total motion is capped; the engine result never depends on the animation.

### Camera director
Choosing a factor glides to its institution and points it out. After 18s idle a slow tour of the points of interest begins. **Any input stops it.**

## Stepped motion (films only)

Explainer films use **12 fps stepped** motion: every eased value is read off a 12 fps grid, so it holds 2–3 frames and reads as handmade.
```js
const FPS = 12;
const step = (ease, dur) => { const f = gsap.parseEase(ease), n = Math.max(1, Math.round(dur * FPS));
  return (p) => f(Math.floor(p * n + 1e-6) / n); };
```
Entrances anticipate (a small move the wrong way), overshoot about 9%, then settle. Use hard wipes between scenes, never dissolves. Keep this to films: the live UI stays smooth.

## The 20 principles (from your `ux-motion` skill; full text in `reference/`)

Squash & stretch (80–150ms, never on text) · Anticipation (60–200ms, 5–25% of the move) · Stagger (30–60ms, under 300ms total) · Follow-through (children lag 20–60ms) · Slow in, slow out · Arcs · Secondary action · Snappy timing · Exaggerated feedback (rare) · Solid drawing in 3D (tilt at most 10–15°, perspective 800–1200px) · Origin awareness · Fitts's law (44pt targets) · Rubber banding · Hick's law · Von Restorff (one highlight per view) · Doherty threshold (under 400ms, feedback within 100ms) · Interruptible · Fast closing · Peak-end (give endings a real moment) · Frequency of use.
