# 04 · Layout and positioning

## Three zones that never compete

```
┌────────────────────────────────────────────────────────────┬──────────────┐
│ PREVIEW (rounded frame, r28, inset 20px)                   │  [tools ⋯]   │ ← one quiet button; unfolds left
│                                                            │ ┌──────────┐ │
│ ┌──┐                                                       │ │ chapter  │ │ ← RAIL (340px, flush right)
│ │+ │  view capsule                 ● dot                   │ │ pill     │ │   cards announce ~5 s, then
│ │- │  (left edge)        ┌──── model ────┐  ┄┄┄┄ callout   │ └──────────┘ │   fold to 64px icon tabs
│ │⟲ │                     └───────────────┘     in margin   │ ┌──────────┐ │
│ └──┘                                                       │ │ info card│ │
│                    ╭─────── conversation ───────╮          │ └──────────┘ │
│                    │ kicker / line / input       │ ← AGENT  │              │
│                    ╰──────────( ◉ globe )────────╯  bottom- │              │
│                                                    centre  │              │
└────────────────────────────────────────────────────────────┴──────────────┘
```

| Zone | Desktop (≥ 1024px) | Purpose |
| --- | --- | --- |
| **Preview** | `position:fixed; inset: 20px (rail-w + 40px) 20px 20px`; radius 28px; studio gradient | The model, shown like a Sketchfab viewer |
| **Rail** | Right column, 340px wide, starting 64px below the top (under the tools); cards flush right | Context, icons first |
| **Agent** | Globe 56px at the bottom centre of the *preview* (`left: var(--fcx)`), 18px above the frame bottom; the conversation grows up out of it, `min(600px, frame width − 64px)` wide, max 46dvh | The only voice |

Other fixed pieces:
- **View capsule** (zoom in, zoom out, top view, reset, pause motion): a vertical glass capsule inside the preview's left edge, 16px in. Its tooltips reveal to the right.
- **Tools**: one quiet button at the top right. Hover or focus unfolds Notebook, Feedback, Settings and Pause to its left with a spring stagger. A small orange dot marks unread feedback.
- **Document controls** (Previous / Read text / Next): a capsule at the bottom centre of the preview. The globe hides while it shows.
- **Notices**: centred on the preview (`left: var(--fcx)`).

## Model framing rules

- Fit the model by the **projected corners of its bounding box**, not its bounding sphere. Use `camera.zoom` and `viewOffset` to fit it into the free region of the preview.
- **Reframe when UI opens.** When the conversation or a card opens, the model moves up and gets slightly smaller so the card never sits on it. Closing restores the view. Short focus or orbit: 450–700ms. Reframe for a panel: 300–520ms.
- The overview shows the whole model with generous margins: about 55–65% of the viewport width.
- Measure visible geometry from base positions only. Morph targets inflate `Box3.setFromObject`.
- **Reading view:** the extracted sheet is measured on screen each frame. Zoom and pan steer it to about 86% of the preview height, just right of centre, with the folder peeking from the left. Any user zoom or pan releases the lock.
- Hold the view **still** once reading or typing starts.

## Callouts: in the margins, never on the model

A point of interest is a 12px glass dot on the object. On hover or focus:
1. the object highlights
2. corner brackets lock onto its on-screen box
3. a dotted leader draws to the **nearest empty margin** of the frame
4. the callout card (248 × 132px, 22px padding from the edges) appears at the end of the line

The callout is placed by testing the free sides of the frame against the model's projected box.

## Pop-ups that do appear

- **Option 1:** cards open centred in the frame, *above* the composer.
- **Option 2:** the composer steps aside, keeping a 20px gap from the card.
- Institution cards **grow from their pin** (origin awareness), not from the screen centre.
- Settings, notebook, feedback and details open as a **panel in the rail** under the chapter card. They do not open as a modal in the middle.

## Title screen (P00): two panels on a grid

- **Left:** a white panel, `--tp-w: clamp(340px, 33vw, 520px)`, background `#faf9f6` (soft off-white, not stark). The title, kicker and Start / Continue are centred on it, and a slowly turning showcase object sits below. Hovering a piece of the office swaps it in, with a cross-fade and caption.
- **Right:** the office on a near-white warm grey (`#f2f1ed`), one step darker than the panel. It swings slowly, about ±50° over about 26s, and never leaves its frame.
- Pause motion sits in the stage's bottom-right corner.
- Phones: the panel is on top (52dvh) and the stage below.

## Character dialogue card with a film

The conversation card widens from 600px to `min(760px, frame − 32px)` and up to 86dvh. A 16:9 film opens at the top (radius 18px), plays while the character speaks, then folds back. Afterwards a small "▶ Map" replay chip sits beside the speaker name.

## Phones (≤ 700px)

| Desktop | Phone |
| --- | --- |
| Preview with a rail beside it | The preview fills the screen (`--gap: 10px`, radius 22px) |
| Rail column | Top area: cards from 66px down, left and right 12px, max 30dvh |
| Tools tips | Hidden (no hover); tools icons at top 12, right 12 |
| View capsule vertical, left | Still vertical on the left, so it never collides with the tools |
| Conversation above the globe | Bottom sheet; the composer is the viewport width − 28px, max 48dvh |
| Film play button on hover | Always visible (`@media (hover:none)`) |

Check every layout at **1366 × 768** and **390 × 844** before calling it done.

## Z-order (low to high)

frame/world 0–1 → markers and dots → rail and tools 6 → composer 8 → agent globe 9 → sorting trays 24 → flying sheet 60 → opener film 100 → glossary popover 120.
