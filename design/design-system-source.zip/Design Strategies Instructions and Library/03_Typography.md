# 03 · Typography

## Fonts

| Role | Font | Source |
| --- | --- | --- |
| Display (titles, headers, questions, evidence-sheet titles, film titles) | **Afacad** Variable, weight 600 | `@fontsource-variable/afacad` |
| Everything else (body, kicker, meta, buttons, inputs) | **Manrope**, 400–700 | Local variable TTF or Google Fonts |

`--display: "Afacad Variable", Afacad, Manrope, system-ui, sans-serif`

History: Bodoni Moda was tried as the display face, and you replaced it with Afacad on 20 Nov 2026. Keep to two families.

## The scale (editorial hierarchy, from the Fashion Illustration Workbook)

| Role | Style | Example |
| --- | --- | --- |
| **Kicker** | Manrope 600, 11px / 1.2, UPPERCASE, letter-spacing 0.2em, `--accent` tan | `THE EVIDENCE` |
| **Hero title** | Afacad 600, `clamp(44px, 5.4vw, 76px)` / 0.98, tracking −0.02em | Title screen |
| **Card title** | Afacad 600, 26px / 1.1 (headline 24px / 1.18), tracking −0.015em | Chapter card |
| **Question** | Afacad 600, 21px / 1.2, tracking −0.01em | "Which response do you choose?" |
| **Body** | Manrope 400, 14.5px / 1.55, `--ink-2` | Card text |
| **Composer body** | Manrope, 15px / 1.55 (14px on phones) | Dialogue |
| **Meta** | Manrope 500, 12px / 1.4, `--ink-3`, `font-variant-numeric: tabular-nums` | Years, counts, sources |
| **Button** | Manrope 600, 13–14px | Pills |
| **Tooltip / label reveal** | Manrope 600, 12px / 1 | Icon tips |
| **Subtitle (voice)** | at least 18px (`max(18px, 1.15rem)`), max ~40 characters per line, `text-wrap: balance` | Captions |
| **Input** | Manrope 600, 18px in the welcome pill | Name field |

Optional: an *italic* accent word inside a display title (`h1 em`).

## Rules

- Everything is **left-aligned**. The exception is the centred title panel on the cover.
- A card holds at most **kicker + title + one short line**. More goes behind a hover or expansion.
- Number sections 01, 02, 03 in tabular figures; never "2 of 6".
- Separate with 1px hairlines at 12% ink, never boxes inside boxes.
- Long words of jargon get a dotted underline and a tap-to-define note (see the glossary in `09`).

## Writing voice (the words matter as much as the type)

- Plain English at B1 level. Short sentences. One idea per line.
- Verbs on buttons: "Open the case file", "Test a response", "Read text".
- Speaker labels are kicker style: `DR AMINA DIALLO · RESEARCH DIRECTOR`.
- A visible summary sits on top, with the full transcript one tap away. Never replace source facts with your own summary.
- Definitions are one sentence, conversational, written for the learner, and approved by a subject expert before release.
- Avoid: "simply", "just", exclamation marks, invented "thinking" narration from the AI.
