# 11 · Process and verification

## How a design round works (what worked on this project)

1. **Gather references.** Videos, screenshots and your own past work (the workbook, earlier simulations) go in a `design/current_references/` folder, with a README saying *what to borrow and what not to*.
2. **Write the spec first.** A numbered spec (`DESIGN_V3_SPEC.md`) with sections for layout, material, type, icons, labels, agent, preview look and build order. Each review round becomes a new section (v3.1, v3.2, v3.3…) recorded as a request → implementation table.
3. **Build in order:** layout shell and tokens → agent → markers and callouts → preview look → special phases. Verify each step before the next.
4. **Verify in a real browser** at 1366 × 768 and 390 × 844:
   - no console errors
   - read the page (accessibility tree) for text and structure
   - screenshot for the look
   - test hover, focus, keyboard and reduced motion
   - check timing in a fronted tab (background tabs pause `requestAnimationFrame`, which looks like a bug but isn't)
5. **Review with you, then record.** Every correction goes into the spec and into "rejected" lists (see `01`), so it never comes back.
6. **Commit with a clear message; push when asked.** Large binaries and masters stay out of git.

## Working with an AI agent (Claude) on this

Give it this folder and these instructions:
- "Follow `00_README.md`. Tokens in `library/tokens.css` are the only source of colour, radius and easing."
- "Nothing may cover the model. Icons first, text on hover or focus. One accent."
- "Build step by step and verify each step in the browser preview before telling me it works."
- "Test in sandbox mode; never touch my saved run."
- "Ask before spending credits, deleting files, pushing or publishing."
- "When I correct something, add it to the spec and the do's and don'ts."

## Handoffs

When work moves between tools or people, ship a handoff zip with:
- `CURRENT_DESIGN_CONTRACT.md` (what is true now)
- `CONTINUE_IN_CLAUDE.md` (what to do next)
- the spec, a changed-files list and the patch

State plainly what was **not** browser-tested. Generated images are approximate guides, not proof of placement.

## Quality gate before calling anything done

- [ ] Nothing covers the subject at any breakpoint
- [ ] All hover reveals also work on focus and touch
- [ ] Every icon button has a name; targets are at least 44px
- [ ] Close is faster than open; nothing idles; everything is interruptible
- [ ] Reduced motion and Pause motion reach the same end states
- [ ] Contrast is at least 4.5:1 (including film words)
- [ ] One orange per view; tan only on kickers
- [ ] No console errors; assets lazy-load; the film is under 1MB
- [ ] Checked at 1366 × 768 and 390 × 844, in a fronted tab
- [ ] Spec and do's and don'ts updated with any new decisions
