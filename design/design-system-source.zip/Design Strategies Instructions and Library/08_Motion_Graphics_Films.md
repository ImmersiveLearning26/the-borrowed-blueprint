# 08 · Motion-graphics films (Vox-style explainers)

These are the short map films that play inside a character's dialogue card while they speak (Dr Diallo P02, 16s; Hon. Mwangi P09, 13.6s). The method works for any explainer clip.

## 1. Start from the voice, not the visuals

- Every beat lands on a spoken phrase. Get phrase timings first:
  - **Whisper**, if it is available.
  - Otherwise ffmpeg silence detection: `ffmpeg -i line.mp3 -af silencedetect=noise=-35dB:d=0.12 -f null -`
- Write a beat table: time → phrase → what appears → which single thing gets the accent colour.

Example (Diallo): 0s Kalinda (the map unfolds) · 0.8s disputed election (capital, ballot box, vote bars, DISPUTED stamp at 2.65s) · 3.85s clashes at the Crossing · 5.96s army mutiny rumours · 8.16s corruption scandal · 10.46s check the evidence (a magnifier sweeps) · 12.02s test the causes (lines to a "?" hub) · 13.63s recommend a response (the map folds into the case file).

## 2. Decide what to generate and what to draw

**Generate** only the illustrative hero objects (about 12–14): ballot box, barrier, gate, radio mast, banknotes, contract, magnifier, scales, houses, census clipboard, notice board, government building, boundary marker, case folder.

**Draw in code** everything that carries meaning or timing: the map, borders, rivers, roads, stamps, bars, arrows, dotted lines, ticks, checklists and **all words and numbers**. Vector-crisp, separately animatable, frame-exact.

If you are generating a whole "scene", stop: you lose per-element staging.

## 3. Props: photoreal cut-outs (your choice), not paper

The prompt recipe is in `library/image_prompt_template.md`. The essentials:
- Nano Banana Pro, **1:1, 2K**, one object per image.
- State the viewing angle ("seen straight on from the front", "clean side profile").
- Pure vivid **green RGB 0,255,0** background. No shadow, no floor, no green spill.
- "Not an illustration, not paper, not a cut-out, not a 3D render. No text."
- Muted, slightly desaturated colours, soft front-left light.
- Rerun anything with text, a green tint, a background shadow or more than one object.

**Keying:** colour-key the green, then clamp G to (R+B)/2 *only where green dominates*. **Never use ffmpeg `despill=type=green`**: it turns cream, grey and brown objects pink. Trim to the alpha bounds and record each aspect ratio. Check them on the real ground colour, not on white.

## 4. Draw the real map, not an invented one

The Kalinda outline was traced from the game's own 3D model:
1. Rasterise the triangles from the top.
2. Follow the edge with a Moore-neighbour trace.
3. Simplify with Ramer–Douglas–Peucker. Split closed loops in half first, or RDP collapses them to two points.
4. Output JSON: base outline, river, city ground, roads, named places in map units.

The film then matches the 3D map the learner sees elsewhere, so the visual language stays consistent.

## 5. Build in HyperFrames (HTML → video)

- One composition, 1280 × 720, a GSAP 3 timeline, **paused** and registered as `window.__timelines["main"]`. It must be deterministic and seek-safe.
- **Layers:** ground → `#cam` wrapper (push-ins: `camAt(point, scale)` puts a point at the optical centre) → map halves (so the map can unfold and fold) → effects SVG → props → top effects → eyebrow title.
- **Eyebrow titles** per beat: Afacad, with one hot word (`.eb b { color: #c24a00 }`).
- **Camera:** push in on each beat's spot, so things read at card size. Pull back for summary beats.
- Illustrative content (such as district lines) must be labelled and approved by a subject expert. The map must never imply a causal result the model doesn't support.

### Motion rules for films
- **12 fps stepped** (see `06`). Anticipate → overshoot about 9% → settle.
- Stage one element at a time, 3–8 frames apart.
- **One accent per beat**, and it leaves with the beat.
- Hard wipes or folds between beats, never cross-dissolves.
- Animate SVG circles by `attr r`, not GSAP scale (scale moves them off position). Sample paths with `getPointAtLength` *before* removing them.
- Fix dead space: content should sit around the optical centre, not packed into the top two-thirds.

## 6. Check stills, then render

```
npx hyperframes check
npx hyperframes snapshot --at 2.65        # one frame per beat; look for collisions and dead space
npx hyperframes render --fps 12 -q delivery -o renders/master.mp4
ffmpeg -i renders/master.mp4 -c:v libx264 -crf 26 -tune animation -pix_fmt yuv420p -movflags +faststart -an renders/<id>_film.mp4
ffmpeg -ss 13.3 -i renders/master.mp4 -frames:v 1 -q:v 3 renders/<id>_poster.jpg
```
Target **under 1MB** (we got 550KB and 387KB). The poster is a late, information-rich frame. Check contrast on every coloured word (at least 4.5:1).

## 7. Embed in the UI

- `<video muted playsinline preload="none" poster data-src>`. The source is set lazily, only when the film plays.
- **Sync to the voice:** the voice player fires `onStart(id)` when `audio.play()` resolves, and the film starts then. Fallback timer: 1600ms with voice, 500ms without.
- The card widens, the film opens, plays and ends, then the card folds back to its actions.
- **First time only**; a replay chip after. Remember "seen" in saved state.
- No autoplay under reduced motion or Save-Data. The play chip still works.
- One pause button controls film and voice together (WCAG 2.2.2).
- Copy renders into `public/films/` with the asset script; keep masters and raw props out of git.

## 8. Opener film

20–25s, 1920 × 1080 at 30 fps, no voiceover. It uses the game's own 3D models and the AI globe, Afacad and Manrope, and rations the orange. It opens with the Miva ident (official logo file, carried in with weight) and ends on warm white, so the title screen continues it. Music is a quiet bed, with sound only on visible actions. The three storyline options considered are in `reference/OPENER_STORYLINES.md`.
