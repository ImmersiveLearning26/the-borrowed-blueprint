# 10 · Do's and don'ts

## Layout
| Do | Don't |
| --- | --- |
| Keep the subject (model, map, document) the hero, with UI in the margins | Put labels, cards or panels on top of the model |
| Reframe the model into free space when a panel opens | Let the conversation card sit over the object being discussed |
| Use three zones: preview, rail, agent | Scatter controls around the screen |
| Centre agent and notices on the *preview* (`--fcx`), not the window | Centre things on the viewport when a rail is present |
| Open detail in the rail, or grow it from its pin | Use a centred modal for detail |
| Dock rail cards flush to the edge; fold them to icon tabs after about 5s | Leave a stack of open cards on screen |
| Check at 1366 × 768 and 390 × 844 | Trust a single desktop screenshot |

## Visual
| Do | Don't |
| --- | --- |
| Use a warm neutral stage (`#ecebe6` / `#f4f3ee`) | Use pure white behind 3D, or a photo backdrop |
| Use frosted glass: blur, a bright top edge, a soft long shadow | Use hard borders, heavy drop shadows or boxes inside boxes |
| Use one radius family; exact circles for round controls | Mix radii, or let 44px min-width turn circles into ovals |
| Use orange `#ff7a1a` for every hover, selected and focus state | Introduce a second interaction colour |
| Use tan only for kickers | Use the accent for decoration |
| Give one highlighted thing per view | Highlight two things (they cancel out) |
| Use Phosphor **bold**, 20px glyphs in 44px circles | Mix icon sets or weights |
| Theme by scene (studio / indigo model / dusk), changing CSS and 3D mood together | Change only the 3D and leave light UI on a dark scene |

## Type and content
| Do | Don't |
| --- | --- |
| Use kicker / Afacad title / one line | Write paragraphs in cards |
| Use Manrope for body, tabular figures for numbers | Use more than two font families |
| Number sections 01, 02 | Write "Chapter 2 of 6" or counts |
| Write B1 plain English with verbs on buttons | Use jargon without a gloss |
| Show a summary with the full transcript one tap away | Rewrite source facts |

## Motion
| Do | Don't |
| --- | --- |
| Stage the container first, then the children (40ms apart) | Bring everything in at once |
| Close 2–3× faster than you open | Close with the same slow curve |
| Use springs for small things and `--calm` for big panels | Overshoot or flash colour on large surfaces |
| Grow things from their trigger | Scale from the screen centre |
| Make motion interruptible (transitions or retargeting tweens) | Use keyframes for reversible UI, or block input during motion |
| Hold the scene still while the learner reads or types | Idle-spin, pulse dots or breathe constantly |
| Stop any automatic tour on input | Auto-play long camera moves on every action |
| Give reduced motion and a Pause toggle the same end state | Simply skip states under reduced motion |
| Use 12 fps stepped motion **in films only** | Step the live UI |

## Agent / AI
| Do | Don't |
| --- | --- |
| Use one globe, hidden until it has something to say | Keep a permanent chat transcript or several voices |
| Morph the conversation out of the globe | Fly particles across the screen |
| Make the "thinking" form honest feedback for real work | Invent thinking narration |
| Stream words after the card opens | Type text before the container is ready |

## 3D
| Do | Don't |
| --- | --- |
| Reuse the user's own models first, and clean their branding | Model from scratch when a supplied asset exists |
| Use one scale per world | Scale props by eye |
| Use AgX, HDR environment, GTAO, subtle bloom only on practical lights, contact shadow | Use bloom on everything, or no ground shadow |
| Use a transparent canvas, with CSS painting the stage | Rely on `scene.background` under AgX (it greys) |
| Use solid wall caps and clean matte plaster | Leave hollow cut walls or noisy normal maps |
| Animate the world without people (vehicles, lights, packets) | Add animated people or new characters |
| Credit CC-BY models | Ship unattributed assets |

## Films
| Do | Don't |
| --- | --- |
| Generate hero props; draw map, lines and all text in code | Generate whole scenes or baked-in text |
| Use photoreal cut-outs on green, keyed with a G clamp | Use `despill=type=green` (pink objects) or paper-cut textures (rejected) |
| Trace the real map from the game's model | Invent a map that doesn't match the game |
| Anchor beats to spoken phrases | Time beats arbitrarily |
| Keep films under 1MB, lazy-loaded, first time only, pausable | Autoplay every visit or ignore Save-Data |

## Process
| Do | Don't |
| --- | --- |
| Build step by step and verify each step in a real browser | Claim a look works without seeing it |
| Test in `?dev=1&sandbox` in your own tab | Test on the learner's or user's saved run |
| Write each design round as a numbered spec section | Change direction without recording it |
| Ask before deleting, publishing or spending credits | Spend paid credits silently |
