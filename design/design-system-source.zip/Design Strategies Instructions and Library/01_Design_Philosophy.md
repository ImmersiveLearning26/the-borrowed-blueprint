# 01 · Design philosophy

## North star

**"Designed by an Apple designer who thinks like a motion-graphics artist."**

Work is judged by whether it feels *thoughtful and calm*. Text-heavy panels and labels sitting on the 3D model were rejected as "choked up" and distracting. The bar is iOS and macOS polish (CleanMyMac, Dynamic Island, Apple Intelligence), plus the editorial confidence of a printed design workbook.

## The five core ideas

### 1. The subject is the hero; nothing covers it
The 3D model, the map or the document is the main visual. UI lives in the *margins* around it.
- When a panel opens, the model **reframes** into the remaining free space (smaller, shifted). The panel never sits on top of it.
- Labels never sit on the model. A point of interest is a small dot. Its explanation appears in an empty margin, joined to the dot by a dotted leader line.

### 2. Icons first, text on request
- Controls are Phosphor **bold** icons in round 44px targets.
- The text label slides out on hover or focus, and is hidden otherwise.
- Cards show at most **kicker + title + one line**. Detail opens on hover, focus or expansion.
- No counts like "Chapter 02 of 06" and no repeated headings. Show the minimum that still orients the learner.

### 3. One voice
- Only **one** surface talks: the AI agent (a glowing globe) and the conversation card that grows out of it.
- The globe is hidden until it has something to say.
- No giant chat transcript and no unsolicited repeated questions. History lives in a Notebook.

### 4. Calm glass on a warm stage
- Material: iOS-style frosted glass (blur 24px, saturation 180%, bright top edge, soft long shadow).
- Stage: a warm neutral (`#ecebe6` page, `#f4f3ee` model stage), **not pure white**. White flattens 3D and gives shadows nothing to sit on.
- Scene moods change the stage: warm studio for rooms, deep indigo when you are "inside the model", dusk for evening scenes.
- **One accent:** orange `#ff7a1a` means hover, selected or focus, everywhere. Brand tan `#a8763e` is used only for kickers.

### 5. Staged, springy, interruptible motion
- Every reveal is choreographed: the container opens first, then its contents rise in order (40ms apart).
- Things open with a soft spring and **close two to three times faster** than they open.
- No idle spinning, no constant pulsing, no bounce for its own sake.
- Reduced motion always gives the same end state instantly.

## Reference influences (what to borrow and what not to)

| Reference | Borrow | Don't borrow |
| --- | --- | --- |
| Fuselab apartment model (navy) | Roofless cutaway diorama; model reframes when a side panel opens; boxy corner-bracket highlight | Dense property labels, minimap, dark background everywhere |
| Airbnb / Orizon diorama | Indigo "inside the model" stage; thin-line emblem drawn with stroke-dashoffset; arcs as progress | Branding |
| Bino MR glass UI (4 images) | Capsule controls, restraint, question capsule floating near an object | Their clocks, capture buttons, flowers |
| Apple Dynamic Island | Conversation morphs out of a circle (clip-path) | Nothing extra |
| Apple Intelligence | Edge glow and a living, glowing orb that changes shape while it thinks | The full-screen glow (it was dropped as too loud) |
| Claude / ChatGPT composer | Input pill that grows with content; tools under the field; greeting-style single question | Chat transcript as the main UI |
| The Fashion Illustration Workbook (Nasara Studios) | Editorial type: tan tracked kicker / display title / one line; numbered sections 01, 02; hairline rules | Its fashion-specific imagery |
| React Bits (Strands, Blinking Dots) | The globe's strand shader; a twinkling dot field around 3D models | Copying code verbatim; it was re-implemented natively in Three.js |
| Vox explainers | Stepped 12 fps motion, rationed accent colour, staged entrances, hard wipes | Paper-cut texture: you chose photoreal cut-outs instead |
| PhET simulations | Small "wiggle" cue on the suggested action, once; conversational help text | Busy toolbars |

## What was tried and rejected (do not repeat)

- **A first-person walk-through office.** Replaced by a roofless isometric cutaway on a plain stage.
- **Photographic backdrops behind the 3D** (a giant tabletop, a city). The stage is plain space, not a photo.
- **Bottom-centre subtitles plus a full-screen edge glow.** Too loud.
- **An upper-right globe with a side composer** (v2). Replaced by the globe at the bottom centre of the preview with a Dynamic Island morph.
- **A centred modal pop-up.** Detail opens as a panel in the rail, or grows from the pin it belongs to.
- **Pulsing scene dots.** They are now still; only the focused callout has a thin travelling thread of light.
- **Chapter numbers and counts.** Removed.
- **Bodoni Moda as the display face.** Replaced by Afacad.
- **A paper-cut look for film props.** You asked for realistic photo objects.
- **A police-themed folder with no hinge.** Branding was painted over and the reused assets were cleaned.
- **Overshoot and colour flashes on large panels.** Large surfaces use a "calm" curve with no overshoot; springs are for small things.
- **Ovals where circles were intended.** Round controls are exact circles (equal width and height).

## Who it's for

Learners on B1-level English, on a laptop or a phone, possibly on a slow connection. Every design choice has to survive:
- a small screen
- reduced motion
- no sound
- a first-time user who has never seen the app
