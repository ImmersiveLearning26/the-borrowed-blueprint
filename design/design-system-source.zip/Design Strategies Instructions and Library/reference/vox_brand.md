# Brand — defaults and how to override

## Default: Xeamless

```ts
export const V = {
  paper:     "#F4F1EC",   // scene ground
  paperDeep: "#E7E0D5",   // alternate ground, marks a chapter change
  card:      "#FBF9F5",   // cards and cut-paper mats
  ink:       "#3B322B",   // all type
  grey:      "#9A948B",   // secondary shapes, bars
  brown:     "#8A6A4F",   // primary object tone, eyebrows
  orange:    "#FF6A00",   // ACCENT ONLY
};
```

Asset palette prompt: `cream off-white, warm light grey, warm mid grey, and mid
brown` — deliberately light, never near-black.

**Type**: Funnel Display. It ships as a variable font; in Remotion, register it
with `weight: "300 800"` behind `delayRender` and Chrome interpolates the axis
exactly, giving true 300/400/500/700. (The "use static instances" advice in the
brand guide is an NLE limitation and doesn't apply here — but static instances
are still needed if titles are ever set natively in Premiere.)

Scale that works on 1080×1920:

| Role | px | weight |
| --- | --- | --- |
| Counter / hero numeral | 190–250 | 700 |
| Scene headline | 92–148 | 700 |
| Landing line | 76–96 | 700 |
| Card label | 78 | 700 |
| Eyebrow | 26, 0.3em tracking, uppercase | 500 |

Tracking sits around −0.035em on display sizes; the font is loose by default.

**Angles**: only −13° and −10°. Everything else is 0. Consistency is what makes
the tilt read as identity rather than as randomness. The tape band and the
diagonal wipe both use −13°.

**The CTA**: an orange tape band at −13° with ink type, across the lower third,
scaling in from the centre with a slight overshoot. Overshoot is allowed on the
band because it's a mark-derived object — never on type.

**Contrast rule worth keeping**: orange type on a teal ground is 3.2:1 and
fails. On an ink ground orange is ~6.5:1 and fine. On the paper ground it's
strong. Check before putting the accent on type over anything but paper or ink.

## Pointing it at another brand

Change three things and the system holds:

1. **`V`** — keep the *relationships*, not the hues. You need a light ground, a
   slightly deeper alternate ground, a near-white card, one dark type colour,
   two mid neutrals, and exactly one accent. If a brand has several accents,
   pick one for the whole piece.
2. **`FONT`** and the size table — a heavier or narrower face may need the
   display sizes pulled down 10–15%.
3. **The asset palette sentence** in the generation prompt, so the objects come
   out in the new neutrals. Name tones, not hex — the model handles "warm slate
   grey and deep navy" far better than "#2E3A4F".

Keep unchanged: the 12fps stepping, the entrance curve, the staging discipline,
the one-accent-per-scene rule, and the single-angle constraint. Those are what
make it read as a system, and they're brand-agnostic.

## A note on the accent

The reason to keep the accent out of the generated art and entirely in the
animation layer is that it lets the accent be *behaviour* rather than
decoration: it arrives on a specific frame, marks one idea, and leaves. That's
what makes the emphasis feel authored. Once it's baked into a still it becomes
just another colour in the picture.
