# Reference

The original documents behind the guide, kept for exact detail. Where they disagree, the numbered guide files (01–12) are current.

- `DESIGN_V3_SPEC.md`: the shipped layout, material, type, icon, label, agent and motion spec, with review rounds v3.1–v3.2
- `CURRENT_DESIGN_CONTRACT.md`: the document sequence, motion values and invariants. Its upper-right globe layout is superseded by v3.
- `DESIGN_DISCUSSION_ADDENDUM.md`: the isometric-model direction and an analysis of the reference video
- `VISUAL_REFERENCES_README.md`: what to borrow from each reference
- `FILM_IMAGE_PROMPTS.md`: all 14 photoreal prop prompts used for the map films
- `OPENER_STORYLINES.md`: three opener film concepts
- `SKILL_ux-motion.md`: the 20 motion principles with numbers
- `SKILL_vox-paper-graphics.md` and `vox_*.md`: the explainer-graphics method (motion, brand, asset prompts)
- `source_code/`: the real shipped files: `v3.css` (all styles), `markers.js` (callout choreography), `agent.js` (globe forms), `glossary.js`, `reel.js` (showcase turntable)
