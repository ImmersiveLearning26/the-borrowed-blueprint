---
name: vox-paper-graphics
description: >-
  Build Vox-style cut-paper motion graphics — generate keyable paper-collage
  assets with Nano Banana Pro, key and trim them, then animate them in Remotion
  with 12fps stepped stop-motion timing, anticipation and overshoot, and render
  a transparent ProRes 4444 overlay for an NLE. Use this whenever the user wants
  paper-cut, collage, explainer, or "Vox-style" animation, animated stills,
  full-screen graphic sections over footage, stat/list/chain explainer beats, or
  a transparent motion-graphics overlay to drop on a timeline. Trigger it for
  requests like "animate these images", "make it look like Vox", "stop motion
  feel", "12fps animation", "paper cutout graphics", or "motion graphics over my
  talking head" — even when Premiere is never mentioned. For the full edit
  including the cut and sync, use vox-paper-edit, which calls into this.
---

# Vox-style cut-paper motion graphics

Paper-cut explainer graphics read as handmade because of two things people
usually get wrong: the motion steps rather than glides, and the accent colour
is rationed. Get those right and fairly simple shapes look expensive.

This skill covers assets → animation → alpha render. If you also need the
footage cut and synced, `vox-paper-edit` owns that and calls into this.

## What you need before starting

Timings. Every entrance is an absolute frame, and if they aren't anchored to
something real — a spoken word, a beat — the result looks arbitrary no matter
how good the easing is. If you're coming from `vox-paper-edit` you'll have a
word/frame table already. If not, ask what each scene should land on.

Read `references/brand.md` for the palette and type. It defaults to the
Xeamless system (warm paper, greys, mid brown, orange accent, Funnel Display)
and shows how to point it at a different brand.

---

## 1. Decide what to generate and what to draw

This is the decision that most affects the result, and the instinct to
generate everything is wrong.

**Generate** the illustrative hero objects — a piggy bank, a wallet, a shutter,
a clock, a stack of notes, pictogram figures, a monitor. Things that would take
an hour to draw and don't need to change.

**Draw in code** everything that carries meaning or timing: cards, bars,
browser chrome, post/tweet cards, strike-throughs, circles, arrows, counters,
rules, and *all type*. These need to be vector-crisp, animate independently,
and land on exact frames. Baking them into a still throws all of that away.

A typical piece is ~12 generated objects and everything else drawn. If you find
yourself generating a "scene", stop — you've lost per-element staging, which is
what makes it read as animation rather than a slideshow.

## 2. Generate the assets

Model: `nano_banana_pro`, `resolution: "2k"`, `aspect_ratio: "1:1"` for isolated
objects. Costs 2 credits per image — preflight with `get_cost: true` if the set
is large.

Read `references/asset-prompts.md` for the prompt recipe. The three things that
matter most:

- **State the viewing angle explicitly** ("seen in clean SIDE PROFILE",
  "straight on from the front"). A generic "flat front-on view" produces a
  shapeless blob.
- **Demand value contrast between layers.** Without it every tone lands within
  ~15 levels of the others and the object turns to mush on a phone.
- **Generate on pure vivid green, not white.** Cream on white cannot be keyed.

## 3. Key and trim

```bash
node scripts/fetch_assets.mjs manifest.json OUTDIR
```

Manifest is `{ "name": "https://...png", ... }`. The script downloads, keys,
suppresses the fringe, trims to the alpha bounding box, and writes
`assets.json` with each asset's aspect ratio (which the composition needs).

**Never use ffmpeg's `despill=type=green` here.** It desaturates green across
the whole image, and since cream, grey and brown all carry green, every object
comes out **pink**. The script instead clamps G to (R+B)/2 only where green
dominates — the palette is untouched because those tones already sit at or
below that line, and only fringe pixels move.

Then look at them composited on the actual paper ground, not on white:

```bash
node scripts/contact_sheet.mjs OUTDIR sheet.png --bg '#F4F1EC'
```

Check for green fringes, pink casts, and whether each object still reads at
thumbnail size. Regenerate anything that doesn't.

## 4. Animate

Copy `assets/kit.tsx` into the Remotion project (e.g. `src/<name>/kit.tsx`).
It provides the stepped clock, the entrance curve, and the paper primitives:
`Ground`, `Obj`, `Line`, `Eyebrow`, `Counter`, `CircleMark`, `Strike`, `Rule`,
`Card`, `Bar`.

Read `references/motion.md` before writing scenes. The essentials:

**Step to 12fps.** Render at 30, but read every animated value off a 12fps
grid. The uneven 2,3,2,3 hold is what makes it read as paper rather than as a
computer tween. `useStepFrame()` does this.

**Nothing appears.** Every entrance anticipates (a small move the wrong way),
overshoots ~9%, and settles. `rise()` is that curve. Exits leave the way they
came in.

**Stage one element at a time.** Two things arriving together halves the
impact of both. Space entrances by 3–8 frames.

**Ration the accent colour.** One idea per scene gets it. It lands on the thing
being emphasised and leaves with the scene. If two things are orange, one of
them isn't the point.

**Hard wipes between scenes, never dissolves.** A diagonal edge sweeping
through is the transition; `Ground` does it on the way in and out.

### Use Remotion's `<Img>`, never a raw `<img>`

A raw tag does not block the render, so single-frame stills catch assets
mid-decode — an object renders as a sliver or vanishes, and it looks exactly
like a layout bug. `Obj` already uses `<Img>`; if you add images by hand,
import `Img` from `remotion`.

### Check stills before rendering

Rendering ProRes 4444 for a minute of video takes a while and produces a
multi-gigabyte file, so don't discover problems there:

```bash
npx remotion still <comp> out/f<N>.png --frame=<N>
```

Pull one frame per scene, composite them over the real footage, and tile them.
Look for: assets that didn't load, layout collisions, and **dead space** —
scenes that pack content into the top two thirds and leave a few hundred pixels
of empty ground at the bottom are the most common flaw. Rebalance so content
sits around the optical centre.

## 5. Render with alpha

`remotion.config.ts` needs:

```ts
Config.setVideoImageFormat("png");     // required for an alpha channel
Config.setPixelFormat("yuva444p10le");
Config.setCodec("prores");
Config.setProResProfile("4444");
```

```bash
npx remotion render <comp> renders/<name>.mov
```

Verify before handing it on: `pix_fmt` should be `yuva444p*`, `nb_frames`
should match the composition exactly, and a frame from a stretch that should be
fully transparent should sample as `00 00 00 00` in rgba.

## 6. Composite a preview

The overlay alone isn't watchable. Burn it over the footage so the user can
judge it:

```bash
ffmpeg -i base.mp4 -i overlay.mov -i base.wav \
  -filter_complex "[0:v][1:v]overlay=format=auto:shortest=1[v]" \
  -map "[v]" -map 2:a -c:v libx264 -crf 19 -pix_fmt yuv420p -c:a aac out.mp4
```

## Real brands and real people

If the piece is about a real company, illustrate it abstractly — a generic
savings-app form, a post card with no handle and no avatar photo. Do not
mock up a real product's UI and do not put words in a real person's mouth by
attributing an invented post to them. Say plainly that you did this; it's a
choice the user should know about rather than discover.
