# Motion — making paper look handmade

## Step to 12fps

Render at 30, read every animated value off a 12fps grid:

```ts
const useStepFrame = () => {
  const f = useCurrentFrame();
  return Math.floor((f * 12) / 30) * (30 / 12);
};
```

30 ÷ 12 is 2.5, so the holds come out 2, 3, 2, 3 frames — slightly uneven, the
way a hand-shot stop-motion pass is. A clean 15fps step (2,2,2,2) reads as
"low framerate video"; the uneven one reads as paper being moved. This one
change does more for the handmade feel than any amount of texture.

Everything animated goes through it, including drift. If some elements step and
others glide, the gliding ones look broken.

## Nothing just appears

Every entrance runs anticipation → overshoot → settle:

```ts
const rise = (t: number) =>
  interpolate(t, [0, 0.16, 0.62, 0.82, 1], [0, -0.14, 1.09, 0.98, 1]);
```

It dips 14% the *wrong way* first, drives to 109%, pulls back to 98%, lands.
Multiply your offset by `(1 - rise(t))`.

Anticipation is what sells weight — an object that just slides in has no mass.
The dip is small enough that nobody consciously sees it; they only notice its
absence.

Exits leave the way they entered, and faster: ~10–11 frames in, ~5–6 out.
Entrances are an event, exits are housekeeping.

## Stage, don't stack

One element at a time, 3–8 frames apart. Two things arriving together halves
the impact of both, and there is nowhere for the eye to go.

The order should follow the sentence. If the line is "months and money", the
months arrive on "months" and the money on "money" — not both on the sentence
start.

## Ration the accent colour

One idea per scene gets it. It arrives on the emphasis and leaves with the
scene. Across a whole piece, roughly 15–25% of scenes should have a strong
accent moment.

If two things in a frame are orange, neither is the point. When you catch
yourself adding a second, ask which one is actually the emphasis and make the
other one ink.

Marks that work: a circle drawn around a phrase, a strike sweeping through
something being dismissed, a rule underlining a landing, a counter, a single
filled pill. All of them *draw on* over 4–7 frames rather than appearing.

## Hard cuts between scenes

A diagonal edge sweeping through, bottom leading the top. Never a dissolve —
a dissolve says "these two things are related"; a hard wipe says "new idea",
which is what a scene change means.

Keep the diagonal consistent across the whole piece (one angle, e.g. −13°). A
transition that changes angle reads as decoration rather than grammar.

## Secondary action

Small motion that follows the main one. Paper drifting a few pixels per second
after it lands, stepped on the same grid. A coin arriving after the object it
falls into has settled, rather than with it.

Keep it under about 3px/sec. Its job is to stop the frame feeling frozen, not
to be noticed.

## Layout

Content wants to sit around the optical centre, roughly 40–55% of frame height
for the anchor element. The most common flaw in a first pass is everything
packed into the top two thirds with a few hundred pixels of dead ground at the
bottom — it reads as unfinished.

Check the whole scene band: something at the top (type or eyebrow), the hero
object through the middle, a landing line low. Leave the very bottom ~250px
clear of anything essential on vertical social video, since platform UI covers it.

## Timing reference

| Move | Frames @30 |
| --- | --- |
| Object / card entrance | 10–11 |
| Type line entrance | 9 |
| Exit (anything) | 5–6 |
| Accent mark drawing on | 4–7 |
| Counter run | 20–24 |
| Scene wipe | 5 |
| Stagger between siblings | 3–8 |
| Minimum scene hold | ~45 (1.5s) |
| Minimum return-to-camera | ~25 (0.8s) — below this, merge scenes |
