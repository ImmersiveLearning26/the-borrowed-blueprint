# Generating keyable cut-paper objects

Model `nano_banana_pro` via the Higgsfield MCP `generate_image`, `resolution:
"2k"`, `aspect_ratio: "1:1"` for isolated objects. 2 credits each.

Jobs come back `pending`. Poll with `job_display(id)` or fetch several at once
with `show_generations(type: "image")`.

## The template

Fill in the two bracketed parts and keep the rest verbatim — each clause is
there because removing it broke something.

```
[OBJECT AND EXPLICIT VIEWING ANGLE] - as a Vox-style cut-paper collage
editorial illustration. Built from layered shapes cut out of textured matte
construction paper with visible hand-scissored slightly irregular edges. Fine
paper grain and a subtle halftone dot texture. A thin tight contact shadow
under each paper layer. STRICT PALETTE for the object: [PALETTE]. STRONG CLEAR
VALUE CONTRAST between adjacent paper layers so every shape reads instantly and
separately at small size. Bold graphic separation, poster-like legibility.
Never near-black, never muddy, no orange. Flat illustration, no perspective
distortion, no gradients, no photorealism, no 3D render. IMPORTANT: one single
centered object on a completely flat uniform pure vivid green chroma key
background RGB 0 255 0 filling the entire frame edge to edge, nothing else in
the image. No green on the object itself. No text, no words, no letters, no
numbers, no logos.
```

Default palette: `cream off-white, warm light grey, warm mid grey, and mid
brown`.

## Why each clause is there

**Explicit viewing angle, first.** "Seen in clean SIDE PROFILE facing left",
"seen straight on from the front". A generic "flat front-on view" makes the
model produce a symmetrical blob with no silhouette — a piggy bank became an
unrecognisable oval. Objects with a characteristic profile (piggy bank, wallet,
coins, banknotes, paper plane) want side profile; screens, clocks, shutters and
figures want front-on.

**Strong value contrast.** Without this instruction every tone lands within
about 15 levels of the others. It looks tasteful at full size and turns to
mush on a phone. This is the single highest-leverage clause.

**Vivid green background, not white.** Cream sits ~15 levels off white — too
tight to key without eating the object's edges. Green gives a real separation
(measured corners come back around 3,253,3 with the background occupying ~70%
of the frame).

**No orange / no accent colour in the art.** Keep the accent entirely in the
animation layer. Then it can arrive on an exact frame, on exactly one idea per
scene, and leave. Baked-in accent colour can do none of that.

**No text, ever.** All type is set in the composition — vector-crisp,
animatable, and in the real brand font. Generated text is also frequently
misspelled.

## Checking the result

Sample the corners and the colour histogram before keying:

```bash
ffmpeg -v error -i img.png -vf scale=120:120 -f rawvideo -pix_fmt rgb24 -
```

Corners should read near `0,255,0`. If the background is patchy or the object
carries green, regenerate rather than fighting it in the key.

## When something comes back wrong

- **Blob with no silhouette** → the angle clause was too generic. Name the view.
- **Everything one tone** → strengthen the value-contrast sentence, or name the
  specific tones per part ("pale cream body against a clearly darker mid brown
  base").
- **Extra objects in frame** → "exactly ONE" / "exactly TWO" in capitals works.
- **Detached-looking parts** (a head floating off a body) is normal for
  cut-paper pictograms and usually reads fine at final size — check the contact
  sheet before regenerating.
