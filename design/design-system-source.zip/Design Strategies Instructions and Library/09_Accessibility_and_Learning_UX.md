# 09 · Accessibility and learning UX

## Accessibility baseline (non-negotiable)

- **Targets** are at least 44 × 44px, even when the glyph is 18–20px. Pad the hit area instead.
- **Every icon button has an accessible name** (`aria-label`); tooltips are decoration. `aria-expanded` and `aria-controls` go on anything that opens something.
- **Focus ring:** `outline: 2px solid #ff7a1a; outline-offset: 2px` on `:focus-visible`. Inputs use a thin 1px orange ring at 60%. Never remove focus without a replacement.
- **Everything that opens on hover also opens on focus** (`:hover, :focus-visible, :focus-within`). Touch devices (`hover: none`) show those controls permanently.
- **Contrast:** at least 4.5:1 for text. Check coloured words in films too (`#e05a00` on paper failed at 2.68:1; `#c24a00` passes).
- **Reduced motion:** honour `prefers-reduced-motion` **and** an in-app *Pause motion* toggle (`body.reduced`), with the same end states instantly. Also stop shader motion, camera tours, wiggles and autoplay.
- **Motion and media can be paused** (WCAG 2.2.2). One control pauses film and voice together.
- **Captions on by default:** at least 18px, about 40 characters per line, balanced wrapping, on a glass background. Settings can turn them off.
- **Text alternative** for every 3D-only task: *Read text* gives an HTML version of each document and is the fallback when WebGL fails.
- **Keyboard:** arrows and PageUp/PageDown move through documents; F and S tag; + and − zoom; Esc closes (and returns focus to the trigger).
- **Choices are announced as radios;** form errors are visible and spoken.
- **Data:** respect `navigator.connection.saveData`. Load films with `preload="none"` and lazy sources. Cap the 3D DPR.

## Learning UX (what research and testing told us)

- **The conversation comes first.** P01 is a welcome bubble with a single input, not a form.
- **Show a summary, keep the source.** A short visible summary with the full transcript one tap away. Never change source facts.
- **Tap-to-define glossary:**
  - Glosses placed right beside the word had the strongest effect in the glossing meta-analyses.
  - Mark only the first appearance of each term.
  - Keep definitions to one conversational sentence.
  - Use one shared popover.
  - Definitions live in one file and need subject-expert sign-off.
- **Guided first run:** a skippable coach note above the first question; the suggested option gets one PhET-style wiggle. Never repeat it.
- **Compare by default:** show "your result" next to "what happened" on the card, without making the learner hunt for it.
- **Remove interruptions:** no unsolicited repeated questions, and at most one question capsule per scene. The assistant folds away while the learner reads.
- **Pacing without pressure:** untimed by default. A "minutes left" hint was an experiment for half of the learners only.
- **Never fake intelligence:** no invented "thinking" narration. The globe's thinking state is honest feedback that work is happening.
- **Preserve every learning task.** Simplifying the presentation must not silently remove evidence, thresholds or reflection.
- **Teaching models are illustrative.** Label them as such (Kalinda is fictional, not a prediction), and never let visuals imply causation the rules don't support.
- **Endings matter (peak-end):** the debrief gives a clear, readable summary with strengths named.

## Test modes

- `?dev=1&sandbox` uses a separate save key. Never test on the learner's real saved run (a real run was once overwritten by tests).
- `?opener=0` skips the opener for testing.
- A hidden developer page switcher (Cmd/Ctrl+Shift+H) and a playtest mode that logs timings.
