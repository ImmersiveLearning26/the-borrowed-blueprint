# Image prompt template: photoreal props for motion graphics

**Settings:** Nano Banana Pro (Gemini 3 Pro Image), aspect ratio **1:1**, resolution **2K**, one image per prompt. GPT-Image-2 or Kling Image 4.0 also work.

**Rerun if:** it has readable text, a green tint on the object, a shadow or floor on the background, or more than one object.

## Template

```
[OBJECT, with 1–2 telling details], seen [VIEW: straight on from the front at eye level | in clean side profile | from a three-quarter view slightly above]. Photorealistic studio product photograph, a real physical object, sharp focus throughout, natural true-to-life materials and colours, slightly muted and desaturated, soft even diffused studio lighting from the front-left, no harsh highlights. IMPORTANT: exactly ONE centered object, the whole object fully in frame with a small margin, on a completely flat uniform pure vivid green chroma key background RGB 0 255 0 filling the entire frame edge to edge. No shadow cast on the background, no floor, no reflections, no green light spilling onto the object, no green on the object itself. Not an illustration, not paper, not a cut-out, not a collage, not a 3D render, not a cartoon. No text, no words, no letters, no numbers, no logos. Square image.
```

## Example

```
A translucent plastic ballot box with a sealed lid and a folded paper ballot half inserted in its slot, seen straight on from the front at eye level. [then the rest of the template]
```

## Avoid green objects

If the object is naturally green (leaves, a green flag), switch the key to magenta RGB 255 0 255 and say so in the prompt.

## After generating

1. Key: colour-key the green, then clamp G to (R+B)/2 only where green dominates. **Never** use `despill=type=green`.
2. Trim to the alpha bounding box; record the aspect ratio in `assets.json`.
3. Look at all the props together on the real ground colour (a contact sheet), not on white.
4. Resize for use (about 440px is plenty for a 1280 × 720 film).

## Generate vs draw (decide before prompting)

- **Generate:** physical hero objects that would take an hour to draw.
- **Draw in code:** maps, lines, arrows, stamps, charts, ticks, cards and every word or number.
