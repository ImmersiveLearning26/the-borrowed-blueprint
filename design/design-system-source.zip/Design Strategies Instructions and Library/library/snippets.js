// Reusable JS patterns from The Analyst's Brief. Framework-free; adapt names to your project.

/* ------------------------------------------------------------------ 1. Reduced motion (OS setting OR in-app toggle) */
export const motion = {
  get reduced() { return matchMedia("(prefers-reduced-motion: reduce)").matches || document.body.classList.contains("reduced"); },
  toggle(on) { document.body.classList.toggle("reduced", on); try { localStorage.setItem("reduced", on ? "1" : ""); } catch {} },
};
export const liteMedia = () => motion.reduced || !!navigator.connection?.saveData;   // no autoplay films

/* ------------------------------------------------------------------ 2. Staged word stream (after the card has opened) */
export function streamWords(el, text, { gap = 34 } = {}) {
  el.textContent = "";
  text.split(/(\s+)/).forEach((w, i) => {
    if (/^\s+$/.test(w)) return el.append(w);
    const s = document.createElement("span"); s.className = "word"; s.style.setProperty("--i", i / 2); s.textContent = w; el.append(s);
  });
  if (motion.reduced) el.querySelectorAll(".word").forEach((s) => (s.style.animation = "none", s.style.opacity = 1));
}

/* ------------------------------------------------------------------ 3. Dynamic Island open/close with staged content */
export function island(el) {
  return { open() { el.classList.remove("closed"); }, close() { el.classList.add("closed"); }, get isOpen() { return !el.classList.contains("closed"); } };
}

/* ------------------------------------------------------------------ 4. Rail "announce, then fold" */
export function announce(ms = 5000) {
  document.body.classList.remove("folded"); clearTimeout(announce.t);
  announce.t = setTimeout(() => document.body.classList.add("folded"), ms);
}

/* ------------------------------------------------------------------ 5. Tween helper (interruptible: starts from the current value) */
export const ease = { out: (t) => 1 - Math.pow(1 - t, 3), inOut: (t) => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  back: (t) => { const c = 1.9; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); } };
export function tween(get, set, to, ms, e = ease.out) {
  if (motion.reduced) { set(to); return () => {}; }
  const from = get(), t0 = performance.now(); let raf;
  const step = (now) => { const k = Math.min(1, (now - t0) / ms); set(from + (to - from) * e(k)); if (k < 1) raf = requestAnimationFrame(step); };
  raf = requestAnimationFrame(step); return () => cancelAnimationFrame(raf);   // call to interrupt; next tween starts from where this stopped
}
export const seg = (p, a, b) => Math.min(1, Math.max(0, (p - a) / (b - a)));   // sub-range of a choreography (e.g. brackets 0–.32)

/* ------------------------------------------------------------------ 6. Callout choreography timings (markers.js) */
// one progress p in 0..1 over IN_MS; reverse over OUT_MS
export const CALLOUT = { IN_MS: 560, OUT_MS: 260, CARD_W: 248, CARD_H: 132, PAD: 22,
  phases: { brackets: [0, .32], leader: [.21, .64], card: [.54, 1] } };   // = 0–180, 120–360, 300–560ms

/* Place a callout in the emptiest margin of the frame around the subject's projected box. */
export function pickMargin(frame, subject, w = CALLOUT.CARD_W, h = CALLOUT.CARD_H, pad = CALLOUT.PAD) {
  const room = { left: subject.left - frame.left, right: frame.right - subject.right, top: subject.top - frame.top, bottom: frame.bottom - subject.bottom };
  const side = Object.entries(room).filter(([k, v]) => v >= ((k === "left" || k === "right") ? w : h) + pad * 2).sort((a, b) => b[1] - a[1])[0]?.[0] || "right";
  const cy = Math.min(frame.bottom - h - pad, Math.max(frame.top + pad, (subject.top + subject.bottom) / 2 - h / 2));
  const cx = Math.min(frame.right - w - pad, Math.max(frame.left + pad, (subject.left + subject.right) / 2 - w / 2));
  return { side, x: side === "left" ? frame.left + pad : side === "right" ? frame.right - w - pad : cx,
                 y: side === "top" ? frame.top + pad : side === "bottom" ? frame.bottom - h - pad : cy };
}

/* ------------------------------------------------------------------ 7. Frame-relative centring (--fcx / --fw) */
export function trackFrame(frameEl) {
  const write = () => { const r = frameEl.getBoundingClientRect();
    document.documentElement.style.setProperty("--fcx", r.left + r.width / 2 + "px");
    document.documentElement.style.setProperty("--fw", r.width + "px"); };
  new ResizeObserver(write).observe(frameEl); write();
}

/* ------------------------------------------------------------------ 8. 12 fps stepped ease for films (GSAP) */
export const stepEase = (gsap, name, dur, FPS = 12) => { const f = gsap.parseEase(name), n = Math.max(1, Math.round(dur * FPS));
  return (p) => f(Math.floor(p * n + 1e-6) / n); };

/* ------------------------------------------------------------------ 9. Film synced to a voice line, first time only */
export function playFilmWithVoice({ video, voice, seen, markSeen, onEnd, fallbackMs = 1600 }) {
  if (seen || liteMedia()) return false;                 // show a replay chip instead
  if (!video.src) video.src = video.dataset.src;         // lazy: preload="none" until now
  let started = false; const go = () => { if (started) return; started = true; video.currentTime = 0; video.play().catch(() => {}); };
  voice.addEventListener("playing", go, { once: true }); setTimeout(go, fallbackMs);
  video.onended = onEnd; markSeen(); return true;
}

/* ------------------------------------------------------------------ 10. Glossary: mark the first appearance of each term */
export function glossify(root, terms /* [[name, RegExp, definition]] */, skip = "button,a,input,textarea,select,label,svg,.gloss,[aria-hidden='true']") {
  const used = new Set([...root.querySelectorAll(".gloss")].map((b) => b.dataset.term));
  for (const [name, re, def] of terms) {
    if (used.has(name)) continue;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (n.parentElement?.closest(skip) ? 2 : 1) });
    let n, m; while ((n = w.nextNode())) { m = re.exec(n.textContent); if (m) break; }
    if (!m) continue;
    const hit = n.splitText(m.index); hit.splitText(m[0].length);
    const b = document.createElement("button"); b.type = "button"; b.className = "gloss"; b.dataset.term = name; b.dataset.def = def;
    b.setAttribute("aria-expanded", "false"); b.textContent = hit.textContent; hit.replaceWith(b); used.add(name);
  }
}

/* ------------------------------------------------------------------ 11. Three.js studio recipe (summary) */
// renderer.toneMapping = THREE.AgXToneMapping; renderer.toneMappingExposure = 1.05; renderer.setClearColor(0, 0) (CSS paints the stage)
// env = PMREM(HDR baked in the room), intensity .8; Hemisphere(0xd6e2ff, 0x4a3524, .5); key Directional(0xffe6c8, 2.5) high & to the side
// passes: Render → GTAO → UnrealBloom(strength .2, radius .45, threshold .96) → grade (contrast 1.08) → Output; DPR ≤ 1.5
// camera: Perspective(28°), direction normalize(1, 1.05, 1); fit by projected bbox corners; reframe on panel open (300–520ms)
// contact shadow: ShadowMaterial({ opacity: .16 }) plane under the model; paper/page materials toneMapped = false
