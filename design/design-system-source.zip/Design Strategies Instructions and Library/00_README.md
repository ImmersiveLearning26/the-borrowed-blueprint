# Design Strategies, Instructions and Library

This is everything we learned building **The Analyst's Brief** (Miva Open University, IRS 103). It is a 3D web simulation with an AI guide, voiced characters and Vox-style map films. It is written so that any future project, by you or by an AI agent, can start from here and not from zero.

It is a working system rather than a mood board. Every number in it was set in the real app and checked in a browser.

## How to use it

1. **Starting a new project?** Read `01_Design_Philosophy.md` and `10_Dos_and_Donts.md` first (about 10 minutes). Then copy `library/tokens.css` into the new project.
2. **Building UI?** Use `02` (tokens), `03` (type), `04` (layout) and `05` (components), with `library/components.css` as the starting code.
3. **Animating anything?** `06_Motion_System.md`. Easing and duration tokens are in `library/tokens.css`; patterns are in `library/components.css` and `library/snippets.js`.
8. **Want to see it working?** Open `library/demo.html` in a browser (double-click). It shows the glass, the icon label reveals, the Dynamic Island conversation, the callout, the glossary, the choices, Pause motion and the four scene themes.
4. **3D scene?** `07_3D_Scene_and_Lighting.md`.
5. **Explainer films or motion graphics?** `08_Motion_Graphics_Films.md` and `library/image_prompt_template.md`.
6. **Learning or teaching product?** `09_Accessibility_and_Learning_UX.md`.
7. **Working with an AI agent (Claude)?** Hand it this whole folder and say: *"Follow `00_README.md` and `11_Process_and_Verification.md`."*

## Contents

| File | What it covers |
| --- | --- |
| `01_Design_Philosophy.md` | The north star, the five core ideas, what was rejected and why |
| `02_Design_Tokens.md` | Colour, glass material, radii, shadows, spacing, themes per scene |
| `03_Typography.md` | Kicker, title, body and meta scale; fonts; writing style |
| `04_Layout_and_Positioning.md` | Three zones, the preview frame, rail, agent, title grid, phones, model framing |
| `05_Components_Library.md` | Every UI component: anatomy, sizes, states, behaviour |
| `06_Motion_System.md` | Easings, springs, durations, choreographies, the 20 motion principles |
| `07_3D_Scene_and_Lighting.md` | Isometric cutaway, camera, lighting moods, post-processing, assets |
| `08_Motion_Graphics_Films.md` | Vox-style map films: plan, props, map, 12 fps stepping, sync, render, embed |
| `09_Accessibility_and_Learning_UX.md` | Targets, focus, reduced motion, captions, glossary, guidance cues |
| `10_Dos_and_Donts.md` | One checklist of rules, including every correction you gave |
| `11_Process_and_Verification.md` | How to work: build in steps, verify in a real browser, specs, handoffs |
| `12_Tech_Stack_and_Libraries.md` | Libraries, versions, tools and what each was used for |
| `library/tokens.css` | Every colour, glass, radius, spacing, type and motion token, plus four scene themes |
| `library/components.css` | Buttons, icon reveal, glass card, Dynamic Island, input pill, rail fold, callout, dot, glossary, choices, film |
| `library/snippets.js` | JS patterns: reduced motion, word stream, interruptible tween, callout margin placement, film sync, glossary, 12 fps step, 3D recipe |
| `library/demo.html` | A live page showing the components working together |
| `library/image_prompt_template.md` | The prop-generation prompt and keying steps |
| `reference/` | The original project specs and the motion skills, kept for exact detail |

## The design in one paragraph

> It should feel designed by an Apple designer who thinks like a motion-graphics artist. Icons do most of the talking. Text appears when asked for. Nothing covers the model. One quiet assistant talks; everything else is calm, frosted glass on a warm neutral stage. Things open with a soft spring and close faster than they open. One accent colour, orange, means "you are touching this". Every moment is staged: one element at a time, in order.
