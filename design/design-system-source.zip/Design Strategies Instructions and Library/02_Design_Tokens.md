# 02 · Design tokens

The full CSS is in `library/tokens.css`. Always use the tokens; never hard-code a colour inside a component.

## Colour: light (default, office and hall)

| Token | Value | Use |
| --- | --- | --- |
| `--page` | `#ecebe6` | Page behind everything (warm neutral) |
| stage | `#f4f3ee` | 3D stage and canvas clear colour; the opener ends on it |
| preview gradient | `radial-gradient(120% 95% at 50% 38%, #fcfbf8 0%, #f1efe9 52%, #e3e0d8 100%)` | Inside the rounded preview frame: a studio sweep |
| `--ink` | `#1d2321` | Titles, primary text, primary button fill |
| `--ink-2` | `#535b57` | Body text |
| `--ink-3` | `#868c88` | Meta, captions, secondary labels |
| `--accent` | `#a8763e` | **Kickers only** (warm tan, from the workbook) |
| `--hair` | `#1d23211f` | 1px hairlines and rings (ink at 12%) |
| `--primary` / `--on-primary` | `#1d2321` / `#fbfaf7` | Primary button |
| `--chip` / `--chip-hover` | `#1d23210d` / `#1d232117` | Quiet button fills (ink at 5% and 9%) |
| `--hot` / `--on-hot` | `#ff7a1a` / `#fff` | **The one interaction accent**: hover, selected, focus ring |

### Meaning colours (sparingly)
| Meaning | Value |
| --- | --- |
| Foundations (trusted) | Blue pen mark **O** |
| Set aside | Red pen mark **X** |
| Badges: strong / mixed / fragile (dark theme) | `#7fd8a6` / `#f2c063` / `#ff8f86` |
| Film emphasis ("DISPUTED" stamp, hot words) | `#c24a00` (passes contrast on paper; `#e05a00` failed at 2.68:1) |

## Colour: scene themes

Switch the theme with `body[data-scene=…]`. Tokens are redefined there, so components need no changes.

**Hall (pale room):** `--page:#e6e2da`; the preview is `radial-gradient(… #f2eee7 0%, #e2dbd0 52%, #cfc6b8 100%)`. It is a deeper warm grey, so the pale room separates from the stage.

**Chair's office, evening (dark dusk theme):**
```
--page:#0f0e14; --ink:#f4efe8; --ink-2:#cdc4b8; --ink-3:#968c80; --accent:#e9b26b; --hair:#ffffff1f;
--primary:#f4efe8; --on-primary:#17141a;
--glass:linear-gradient(180deg,#2d2530b8,#1c1820b8); --glass-solid:#211c24f0;
--glass-edge:inset 0 1px 0 #ffffff2b, inset 0 0 0 1px #ffffff12, inset 0 -1px 0 #00000040;
--glass-shadow:0 1px 2px #0000004d, 0 20px 54px #00000099; --chip:#ffffff14; --chip-hover:#ffffff24
preview: radial-gradient(120% 100% at 50% 118%, #7a4a22 0%, #3a2630 32%, #17151f 66%, #0f0e14 100%)  /* lamp glow from below */
```

**Orizon "inside the model" stage (simulation chapter):** a deep near-black to indigo gradient, `#0d0e17 → #1b1640 → #3a2a8a` (glow at the bottom). Glass turns smoky (white at 8–12%). It tells the learner "you are inside the model now".

**Film palette (map explainers):**
```
--ground:#f4f1ec  --land:#e7dcc6  --land-edge:#c8b38c  --city:#d9cbae  --road:#bba57f  --river:#8fb0c4
--ink:#2a2622  --mute:#8a7f70  --hot:#c24a00 (one idea per beat)
```

## Material: liquid glass

```css
--glass: linear-gradient(180deg, #ffffff8c, #ffffff5e);     /* white 55% → 37% */
--glass-solid: #fbfaf7e6;                                     /* for dialogs and tooltips that must be legible */
--glass-blur: blur(24px) saturate(180%);
--glass-edge: inset 0 1px 0 #ffffffd9, inset 0 0 0 1px #ffffff59, inset 0 -1px 0 #0000000a;   /* bright top, faint ring, darker lower edge */
--glass-shadow: 0 1px 2px #1416140f, 0 14px 44px #1416141a;   /* tight contact + soft long shadow */
```
Rules:
- No hard borders.
- No heavy drop shadows.
- Depth comes from blur and highlight.
- `border: 0` on every glass element.

## Shape: one radius family

| Thing | Radius |
| --- | --- |
| Preview frame | 28px (22px on phones) |
| Cards and rail panels | 24px |
| Conversation card | 28px |
| Small cards, list rows, film frame | 14–18px |
| Buttons and pills | 999px (capsule) |
| Icon buttons | 50% (an exact circle; width = height) |

Rail cards dock flush to the right screen edge: rounded on the left, square on the right.

## Spacing and sizes

| Token | Value |
| --- | --- |
| `--gap` | 20px desktop, 10px phones (the inset of every zone from the screen edge) |
| `--rail-w` | 340px |
| Card padding | 20px 20px 18px |
| Composer padding | 22px 24px (84px bottom while the input sits inside) |
| Icon target | 44 × 44px, icon glyph 20px (18px inside small buttons) |
| Button height | 40px minimum in cards, 44–48px for main actions |
| Row gap in stacks | 6px; groups 12px |
| Hairline | 1px at 12% ink |

`--fcx` (the centre x of the preview frame) and `--fw` (the frame width) are written by JS from the frame's box. Anything that centres "in the preview", such as the agent, document controls and notices, uses `left: var(--fcx); translate: -50% 0`.
