# 05 · Components library

Each entry gives anatomy, sizes, states and behaviour. Starting CSS for most of them is in `library/components.css`.

---

## Icon button with label reveal (`.ib`)
- **Anatomy:** a 44px circle → a 20px Phosphor bold glyph (`fill: currentColor`) → a `.tip` label pill.
- **Rest:** glass circle, ink glyph, label hidden (opacity 0, scale 0.9, offset 6px).
- **Hover / focus:** the button scales to 1.08 (220ms `--pop`) and fills **orange with a white glyph**. The label slides out 6–8px and fades in (200–240ms ease-out, 60ms delay).
- **Press:** scale 0.96 for 90ms.
- **Leave:** the label goes in 120ms ease-in (faster than it came).
- Every button has an `aria-label`. Tips are hidden on phones.

## Glass card (`.card`)
- Radius 24px, padding 20/20/18, `--glass` + blur + edge + shadow.
- Content: kicker → Afacad title 26px → one line at 14.5px → actions.
- Buttons inside: quiet chips (`--chip`, capsule, 40px). The primary button is ink-filled. Hover on any button is orange.
- Meters: a 3px hairline track with an ink fill.

## Chapter pill (rail)
- A compact pill: icon + title, with no numbers.
- Hover, focus or click expands it to show its line and a set of step icons.
- **Calm expand:** `cubic-bezier(.22,.8,.24,1)`, 380ms, 70ms hover-intent delay; the words follow at 200ms. Collapse: 300ms with a 240ms delay, so passing the mouse over it doesn't flicker it.

## Announce-then-minimise rail cards (`.card.peek`)
- On a new chapter or info card, `body.rail-announce` holds every card open for about 5s.
- After that, each card folds to a **64 × 64 icon tab** (an ink circle with a white icon) and the model reframes to the full preview.
- Hover or focus reopens the card.

## Agent globe
- A 56px WebGL orb (a port of React Bits *Strands*).
- **Phases:**
  - **hidden:** scale 0.6, opacity 0
  - **prompt:** low energy
  - **working:** scale 1.12, strands quicken, glow rises, hue drifts
  - **listening:** gentle speed
- **Thinking form:** a glowing shell morphs circle → rotated square → blob → circle, and two thin Orizon arcs orbit it. Shape changes tween over 600ms ease-in-out and never snap.
- While it speaks, it breathes. Before each new line it "thinks" for about 0.5s, then words arrive one by one, 34ms apart.
- It hides while document controls are visible.

## Conversation card (Dynamic Island morph, `#composer`)
- **Open:** `clip-path` goes from the globe's circle (`inset(calc(100% - 74px) calc(50% - 37px) 0 … round 37px)`) to the full card (`inset(0 round 28px)`) over **460ms `--ios`**. Then the children rise 10px and fade in, staggered 140 / 180 / 220 / 260 / 300ms.
- **Close:** clip back in **260ms ease-in**; the children vanish in 80ms.
- It sizes to its content, 380–640px (600px default), max 46dvh, scrolling inside.
- **Rest state for dialogue:** after the line plays, the spoken text (`.say`) folds away (max-height 0, 420ms) and a **Hide / Show** chip beside the speaker brings it back.

## Input bar (chat composer)
- One glass pill: `[globe] field [mic/waveform] [send]`.
- The field starts compact and grows with its content (like Claude's input), never wider than 640px.
- With tools: the field on top and the controls below.
- **Focus:** a thin 1px orange ring at 60% (`#ff7a1a99`), never a heavy border.
- **Send:** an ink circle that turns orange on hover.
- Field hints fade between messages.
- **Welcome variant (P01):** the input pill springs out of the speech bubble (scale 0.6 → 1, 420ms `--ios`). On submit it is "absorbed" back into the bubble (scale 0.08, 440ms).

## Voice mode
- Only the globe shows, larger, at the bottom centre.
- The question sits above it and the live transcript below.
- Subtitles are on by default and can be turned off in Settings.

## Choices (single choice)
- Wrapped cards, each with a radio dot and the lever as an Afacad question, announced to screen readers as radios.
- Selected: orange fill with white text.
- **Factor picker:** a quiet pill with a caret; its menu rises above it.

## Tag pins and marks (sorting evidence)
- **Blue O = Foundations; red X = Set aside.**
- Chips look like paper, and the mark *draws on* (stroke-dashoffset) when chosen. The same mark is drawn on the document texture.
- **Sorting folders (trays):** a 150px 3D column on the right, with two hit areas (top: Foundations, bottom: Set aside). They appear in 320–420ms.
- The chosen sheet **flies** to its folder as a real fold: the top half stays flat and the bottom half rotates in 3D (`perspective: 1400px`). A thin 1.5px rectangle draws around it, never bold.

## Point-of-interest dot and callout HUD
- **Dot:** 12px glass, still (no pulse). On hover it fills orange with a white core.
- **Sequence:** highlight 0ms → brackets 0–180ms → dotted leader 120–360ms → card 300–520ms. Leaving reverses at about twice the speed (260ms).
- **Callout:** a near-black high-contrast HUD, white type, orange kicker, orange brackets and leader. The card springs out of the line's end. In focus, a thin thread of light travels around its edge.
- Content: kicker / title / one line. No counts.

## Question capsule (Bino-style)
- At most once per scene, after about 8s idle, a small capsule floats up near a relevant object ("What does the Barracks stand for?").
- Clicking it opens that object's callout. It dismisses itself after 6s.

## View capsule (`#viewDock`)
- A vertical glass capsule, radius 28px, padding 5px, with 44px buttons: zoom in, zoom out, top / front / isometric, reset, pause motion.
- Hairline separators. Hover is orange.
- This is the reliable view control, because orbit-drag is disabled while the composer is open.

## Document reader (front-facing)
1. The folder lifts and aligns square to the view (about 420ms).
2. The cover opens while the folder holds still (400–460ms).
3. Exactly one sheet slides straight right (about 300ms). No curl, fanning or diagonal drift.
4. Tags apply directly. Next / Previous returns the current sheet along the same path, then brings out the next.
5. Close: the paper returns, the cover closes, the folder lowers (about 350ms).
- Keys: arrows, PageUp and PageDown, **F** (Foundations), **S** (Set aside), **+ / −** (zoom), **Esc** (close).
- *Read text* is an HTML alternative and also the fallback when 3D fails.
- Paper legibility: page type at 58px body on the texture, near-white paper, `toneMapped = false` on page materials.

## Map film in a dialogue card (`figure.film`)
- **Anatomy:** a 16:9 frame, radius 18px, background `#f4f1ec`, hairline ring, `<video muted playsinline preload="none" poster>`, and a 40px round glass pause button (bottom right).
- **Open:** the card widens (460ms `--ios`), the film's max-height goes 0 → 440px, and opacity fades in over 220ms.
- The pause button appears on hover, focus or pause, and is always visible on touch. It pauses the video **and** the voice together. Its `aria-label` switches between "Pause the map film" and "Play the map film".
- Plays automatically the first time only; afterwards a "▶ Map" replay chip. No autoplay with reduced motion or Save-Data on.

## Glossary term (`button.gloss`)
- It looks like a word, not a button: a dotted 1.5px underline at 55% of the text colour, offset 3px, cursor help. On hover the underline turns orange.
- Tap or click shows one shared popover beside the word: 300px max, radius 14px, glass-solid, with **Term** in bold and one sentence after it. It flips above when there is no room below. Esc, scroll, resize or an outside click closes it.
- Only the **first** appearance of each term in a block is marked.

## Coach note (guided first run)
- Above the question: a chip-filled box, radius 16px, hairline ring, 15px text, with a Skip button.
- The suggested option gets a small **wiggle** (±3px, 600ms, twice) and a thin orange ring, **once**, and not with reduced motion.

## Result comparison line
- A two-column grid: muted label / bold value ("Your result · What happened"), 13px, shown on the card by default.

## Response package (P11)
- A numbered grid: lever label / choice (bold) / round edit button. The tested view shows level badges and a time meter in the footer.

## Debrief rows
- Numbered rows with **Strong / Mixed / Fragile** badges, readable in both light and dark themes.

## Opener film shell
- A full-screen dark `#121219` grid. The video is `object-fit: contain`.
- Skip and Sound are glass capsules bottom right (44px).
- The film **ends on warm white** (`#f4f3ee`), so the title screen continues it seamlessly, with a 420ms fade.
- The Miva Open University ident opens it, using the official logo file, never redrawn.

## Showcase reel (title panel)
- One office object, lit like the main viewer (same HDR, AgX, 28° lens, warm key, soft contact shadow), sways slowly (`-0.6 + sin(t·0.35)·0.5` rad).
- Hover swaps the object with a cross-fade: out, then in, at 4.5× per second.
- It renders only while visible. DPR is capped at 1.5.
