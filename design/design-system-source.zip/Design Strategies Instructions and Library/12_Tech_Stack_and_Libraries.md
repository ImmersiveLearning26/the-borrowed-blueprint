# 12 · Tech stack and libraries

## Web app
| Library / tool | Version | Used for |
| --- | --- | --- |
| Vite | 8.3.8 | Dev server (port 5180) and build; `?raw` imports for SVG icons |
| three.js | 0.187.0 | 3D: GLTFLoader + DRACOLoader, HDRLoader, RoomEnvironment, EffectComposer, GTAOPass, UnrealBloomPass, ShaderPass, OutputPass, AgX tone mapping |
| @phosphor-icons/core | ^2.1.1 | Icons, **bold** weight, inlined as SVG (inherit `currentColor`, no icon font) |
| @fontsource-variable/afacad | ^5.3.0 | Display font |
| Manrope | variable TTF | Body font |
| React Bits *Strands* (ported) | — | The agent globe's WebGL strand shader (`strands.js`) |
| React Bits *Blinking Dots* (reimplemented) | — | Twinkling point field around 3D scenes |
| Plain CSS | — | Tokens, `linear()` springs, `clip-path` morphs, `backdrop-filter` glass, `:has()`, `text-wrap: balance`, `color-mix()` |
| No UI framework | — | Vanilla JS modules: `main.js`, `world.js`, `markers.js`, `agent.js`, `inspector.js`, `glossary.js`, `reel.js`, `trays.js` |

Key modules and what to reuse from them:
- `markers.js`: dot → brackets → leader → callout choreography, margin placement
- `agent.js` and `strands.js`: globe phases and the shape morph
- `inspector.js`: the document lift, open and slide sequence
- `glossary.js`: first-appearance marking and the shared popover
- `reel.js`: a single-object turntable lit like the main viewer
- `world.js`: the MOODS table and the post-processing chain

## 3D production
| Tool | Used for |
| --- | --- |
| Blender 5.3 (via the Blender MCP) | Scene assembly, cleanup, authored animation loops (NLA clips), GLB export |
| glTF / GLB + Draco + WebP | Runtime models |
| gltf-transform (core, extensions, draco3dgltf) | Reading GLBs to trace the map outline |
| PIL / numpy | Rasterising and tracing (Moore-neighbour plus RDP) |

## Films and media
| Tool | Used for |
| --- | --- |
| HyperFrames CLI 0.9.77 | HTML → video (`check`, `snapshot --at`, `render --fps 12 -q delivery`) |
| GSAP 3.15 | Paused, deterministic timelines inside compositions |
| ffmpeg | Silence detection for beat timing, H.264 re-encode (crf 26, `-tune animation`, faststart), posters |
| Nano Banana Pro (Gemini 3 Pro Image) | Photoreal props on green (GPT-Image-2 or Kling Image 4 also work) |
| `fetch_assets.mjs` (vox-paper-graphics skill) | Keying with a G clamp, trim, `assets.json` with aspect ratios |
| ElevenLabs | Character voices (requires a paid, current account) |

## Skills used (in `~/.claude/skills/`)
- **ux-motion**: the 20 motion principles with numbers (copied in `reference/`)
- **vox-paper-graphics**: generate / key / animate / render explainer graphics (copied in `reference/`)
- **hyperframes**, **hyperframes-animation**, **motion-graphics**: the HTML video toolchain
- **web-design-guidelines**: interface review checklist
