# 07 · 3D scene and lighting

## Presentation

- A **roofless isometric cutaway** model on a plain stage. The learner is off-screen. There is no walk-through.
- **Camera:** a 28° perspective camera (an "isometric-style" lens, not true orthographic), looking along `(1, 1.05, 1)` normalised, with a bounded orbit:
  - elevation and zoom are constrained
  - the model stays upright
  - drag is told apart from click
  - buttons give front, top and isometric views
- Model and camera move as **one coherent system**. Furniture never moves independently to fake a camera move.
- **Walls read solid.** Thicken the walls at runtime; cut faces show a flat cap colour (a cross-section look), not a hollow plane. Use a uniform section cut (for example 1.3m) in plan-model rooms. Near walls seen from behind are cut via `!gl_FrontFacing` down to a sill.
- Use clean matte plaster. Busy normal maps read as stains at this scale.

## Rendering recipe (Three.js 0.187)

```
renderer: antialias, AgXToneMapping, exposure ≈ 1.05, sRGB output, PCF soft shadows, transparent canvas (CSS owns the stage colour)
environment: HDR baked inside the room (PMREM), environmentIntensity 0.8; RoomEnvironment as a 0.4 fallback while it loads
lights: HemisphereLight(0xd6e2ff sky, 0x4a3524 ground, 0.5) + warm key DirectionalLight(0xffe6c8, 2.5) high and to the side
post: RenderPass → GTAO (ambient occlusion) → UnrealBloom (strength 0.2, radius 0.45, threshold 0.96: only practical lights glow)
      → grade pass (contrast ≈ 1.08 around mid-grey in linear light, saturation, optional vignette) → OutputPass
contact shadow under the model: ShadowMaterial plane, opacity ≈ 0.16
DPR capped at 1.5
```
Note: AgX greys `scene.background`. Keep the canvas transparent and let CSS paint the stage.

## Moods per scene (one table drives everything)

| Scene | env | exposure | sun | lamp | stage | contrast | Feel |
| --- | --- | --- | --- | --- | --- | --- | --- |
| office | .8 | 1.05 | 2.5 | 1.4 | `#f4f3ee` | 1.08 | Warm key against a cool fill; the desk lamp is a practical light |
| model (Kalinda) | .8 | 1.05 | 2.5 | 0 | indigo stage | 1.08 | "Inside the model" |
| hall | .85 | 1.05 | 2.4 | 0 | `#f4f3ee` | 1.08 | Studio look, deeper grey frame |
| chair (evening) | .32 | 1.0 | 0 | 3.4 | `#12111a` | 1.12 | Dusk; the lamp is the key light, cool window spill, low ambient |

Change mood, CSS theme (`body[data-scene]`) and stage gradient **together**.

## Ambient life (no people)

- **Blinking dots:** a jittered two-layer point field around the model, with a size-driven colour ramp per scene, gentle twinkle, slow drift and cursor parallax. (After React Bits "Blinking Dots", rebuilt natively.)
- **Authored loops from Blender:** edge pulses along roads and borders, mast rings, network packets. They play only in the model chapter and energise during a test run.
- **Outcome animation:** vehicles, stalls and lights by year and outcome, 10s (2s per year), **never people**.
- No idle auto-spin anywhere except the title screen's slow swing.

## Points of interest in 3D

Dots are anchored to 3D positions and projected each frame; their labels and cards are screen-space, so orbiting never tilts the text. Only the current task's markers are visible.

## Asset strategy

1. **Reuse first.** Assemble scenes from your own supplied models and earlier projects (the Evidence Room, office assets, the user's city GLB) before modelling anything. Model an original only when no supplied piece meets a hard requirement (for example a hinge rig), and say why.
2. **Clean reused assets:** strip police branding, real-person photos and old case content; paint over labels.
3. **One scale for a world** (Kalinda used 1:450 for everything).
4. **Budgets:** about 60–75k triangles per scene, an initial download of about 10MB. Use Draco plus WebP textures. Decimating below 0.05 breaks city facades.
5. **Blender → GLB:** export with `use_active_scene=True` (or every scene is written). Imported image names collide across files, so resolve textures through objects. Use fresh 8-bit images for capped textures, or the WebP step fails.
6. **Credit CC-BY models** in the credits screen (for example "Office Room" by golukumar, "Folders" by I3D, the hall by Pedro Silva, the city GLB).
7. Axis conversion from Blender (x, y, z) to three (x, z, −y): convert once, in one helper.

## Paper and documents in 3D

- Paint page textures at runtime from text: body at 58px on the canvas, near-white paper.
- Page materials use `toneMapped = false`, so AgX doesn't grey the paper.
- When a document is held, blur and darken the room behind it and draw the file sharp on top.
- Morph-target folders: measure from base positions; hide the page-edge fan only while a sheet is held.
